
# Mini Pranto Backend

This is the backend server for the Mini Pranto chatbot. It uses Flask and OpenAI's GPT model to respond to chat messages.

## Deployment

Deploy to [Render.com](https://render.com) or Railway.

### Environment Variables

- `OPENAI_API_KEY` — Your secret OpenAI API key

### Endpoint

POST `/chat`  
Payload:
```json
{ "message": "Your question here" }
```
Returns:
```json
{ "reply": "AI's answer here" }
```
